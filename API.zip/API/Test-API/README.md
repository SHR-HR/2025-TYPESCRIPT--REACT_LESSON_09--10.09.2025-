# Test-API — учебный FastAPI-бэкенд для постов

Мини-API для урока №9: CRUD по постам, загрузка изображений, Basic Auth, CORS и Docker.
Хранилище — **память процесса** (in-memory), база данных не используется.

- Документация Swagger: `GET /docs`
- Альтернативная документация ReDoc: `GET /redoc`
- Healthcheck: `GET /healthz`

---

## ✨ Возможности

- **CRUD /api/posts** с пагинацией через `_start` и `_limit` (новые сверху).
- **Загрузка изображений** `POST /api/upload` (поле формы `file`), статика раздаётся с `/uploads/*`.
  - Разрешённые форматы: **.jpg, .jpeg, .png, .gif, .webp**
  - Лимит размера файла настраивается (по умолчанию **10 МБ**)
- **Basic Auth** на всех маршрутах `/api/*` (логин/пароль задаются через переменные окружения).
- **CORS**: белый список origin’ов (список доменов; нужен для фронта на Vite).
- Утилитарные маршруты: `/healthz`, `/` (сводка).

> ⚠️ Данные живут **только в памяти** и стираются при рестарте.

---

## 🧩 Переменные окружения

| Переменная            | По умолчанию                   | Назначение                                                                 |
|-----------------------|--------------------------------|-----------------------------------------------------------------------------|
| `ADMIN_USER`          | `admin`                        | Логин для Basic Auth                                                       |
| `ADMIN_PASSWORD`      | `123`                          | Пароль для Basic Auth                                                      |
| `FRONTEND_ORIGINS`    | `http://localhost:5173,http://127.0.0.1:5173` | Список разрешённых Origin’ов (через запятую)                               |
| `MAX_UPLOAD_MB`       | `10`                           | Максимальный размер загружаемого файла в мегабайтах                        |

**Примеры экспорта:**

- **PowerShell (Windows):**
  ```powershell
  $env:ADMIN_USER="admin"; $env:ADMIN_PASSWORD="123"
  $env:FRONTEND_ORIGINS="http://localhost:5173"
  $env:MAX_UPLOAD_MB="10"
  ```
- **bash (Linux/macOS/WSL):**
  ```bash
  export ADMIN_USER=admin ADMIN_PASSWORD=123
  export FRONTEND_ORIGINS=http://localhost:5173
  export MAX_UPLOAD_MB=10
  ```

---

## 🚀 Быстрый старт (локально, без Docker)

```bash
# 1) Создай и активируй venv
python -m venv .venv
# Windows (PowerShell)
. .venv/Scripts/Activate.ps1
# Linux/macOS
# source .venv/bin/activate

# 2) Установи зависимости
pip install -r requirements.txt

# 3) (опционально) задай переменные окружения, см. выше

# 4) Запусти
python main.py
# Сервер поднимется на http://localhost:8000
```

---

## 🐳 Docker

### Сборка образа
```bash
docker build -t student-api .
```

### Запуск контейнера
```bash
# Linux/macOS/WSL
docker run --rm -p 8000:8000 \
  -e ADMIN_USER=admin \
  -e ADMIN_PASSWORD=123 \
  -e FRONTEND_ORIGINS=http://localhost:5173 \
  -e MAX_UPLOAD_MB=10 \
  -v "$(pwd)/uploads:/app/uploads" \
  student-api

# Windows PowerShell (путь к каталогу uploads смонтируется внутрь контейнера)
docker run --rm -p 8000:8000 `
  -e ADMIN_USER=admin `
  -e ADMIN_PASSWORD=123 `
  -e FRONTEND_ORIGINS=http://localhost:5173 `
  -e MAX_UPLOAD_MB=10 `
  -v "${PWD}/uploads:/app/uploads" `
  student-api
```

> Монтирование `uploads` делает загруженные файлы **персистентными** между перезапусками.

---

## 🔐 Авторизация (Basic Auth)

Все эндпоинты под `/api/*` требуют Basic Auth.

Быстрая проверка:
```bash
curl -i -u admin:123 http://localhost:8000/api/me
```

Ответ:
```json
{ "username": "admin", "message": "Привет, admin! Авторизация успешна." }
```

---

## 📬 Эндпоинты

### Служебные
- `GET /` — краткая сводка: версия, allowed origins, количество постов.
- `GET /healthz` — healthcheck `{status, time, version}`.
- `GET /docs` / `GET /redoc` — интерактивная документация.

### Авторизация
- `GET /api/me` — проверка Basic Auth.

### Загрузка файлов
- `POST /api/upload` — multipart/form-data с полем `file`.
  ```bash
  curl -u admin:123 -F "file=@./pic.png" http://localhost:8000/api/upload
  ```
  Ответ:
  ```json
  { "url": "http://localhost:8000/uploads/<uuid>.png", "size": 123456 }
  ```

### Посты (CRUD)
Модель `Post`:
```json
{
  "id": "string",
  "title": "string",
  "content": "string",
  "author": "string",
  "image_url": "string|null",
  "created_at": "2024-09-10T10:00:00Z",
  "updated_at": "2024-09-10T10:00:00Z"
}
```

- `GET /api/posts?_start=<int>&_limit=<int>` — список постов (новые сверху).
  ```bash
  curl -u admin:123 "http://localhost:8000/api/posts?_start=0&_limit=5"
  ```

- `GET /api/posts/{id}` — один пост.
  ```bash
  curl -u admin:123 http://localhost:8000/api/posts/<id>
  ```

- `POST /api/posts` — создать пост (**201 Created**).
  ```bash
  curl -u admin:123 -H "Content-Type: application/json" \
    -d '{"title":"Заголовок","content":"Текст","author":"Автор","image_url":null}' \
    http://localhost:8000/api/posts
  ```

- `PUT /api/posts/{id}` — обновить пост (частичное обновление полей).
  ```bash
  curl -u admin:123 -X PUT -H "Content-Type: application/json" \
    -d '{"title":"Новый заголовок"}' \
    http://localhost:8000/api/posts/<id>
  ```

- `DELETE /api/posts/{id}` — удалить пост (**204 No Content**).
  ```bash
  curl -u admin:123 -X DELETE http://localhost:8000/api/posts/<id>
  ```

- `POST /api/demo-data` — создать пару демонстрационных постов.
  ```bash
  curl -u admin:123 -X POST http://localhost:8000/api/demo-data
  ```

---

## 🔧 Интеграция с фронтендом (Vite)

В dev-режиме удобно проксировать запросы на API:

```
# front/.env.local
VITE_API_URL=/api/posts
```

Прокси в `vite.config.ts` (на стороне фронта):
```ts
server: {
  proxy: {
    '/api':     { target: 'http://localhost:8000', changeOrigin: true },
    '/uploads': { target: 'http://localhost:8000', changeOrigin: true },
  },
},
```

Если прокси не используете — укажите **полный** URL:
```
VITE_API_URL=http://localhost:8000/api/posts
```

CORS на бэкенде должен включать ваш фронтовый origin (см. `FRONTEND_ORIGINS`).

---

## 🗃️ Зависимости (важное)

- `fastapi`, `uvicorn[standard]`, `pydantic`, `python-multipart`, `aiofiles` — версии закреплены в `requirements.txt`.
- В Docker-сборке используется образ `python:3.11-slim`.

---

## ⚠️ Ограничения и заметки

- API демонстрационное: **нет БД**, все данные — в памяти.
- Для персистентности загружаемых файлов смонтируйте том/папку `uploads`.
- При `allow_credentials=true` CORS **нельзя** указывать `*`; используйте список origin’ов.
- В продакшне отключайте `--reload` и используйте процесс-менеджер (gunicorn/uvicorn workers).

---

## 📄 Структура директорий (кратко)

```
Test-API/
├─ main.py
├─ requirements.txt
├─ Dockerfile
├─ .dockerignore
├─ .gitattributes
└─ uploads/            # создаётся автоматически; хранит загруженные файлы
```

---

Готово! Запускай, подключай фронт и экспериментируй 🚀


Версия API: 1.2.0
Лицензия: Учебный проект
