# Импорт необходимых модулей и классов из FastAPI и стандартной библиотеки Python
from fastapi import FastAPI, HTTPException, Depends, UploadFile, File, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import List, Optional, Dict
from pathlib import Path
from datetime import datetime, timezone
import uuid
import os

# Версия приложения (семантическое версионирование: MAJOR.MINOR.PATCH)
__version__ = "1.2.0"

# ------------------------------------------------------------------------------
# Конфигурация
# ------------------------------------------------------------------------------

# Разрешённые фронтовые происхождения (CORS).
# ВАЖНО: при allow_credentials=True нельзя origin="*".
# Список доменов, которым разрешено делать запросы к API
DEFAULT_ORIGINS = [
    "http://localhost:5173",    # Стандартный порт для Vite/React разработки
    "http://127.0.0.1:5173",    # Альтернативный localhost
]

# Получение разрешенных origin'ов из переменных окружения
origins_env = os.getenv("FRONTEND_ORIGINS")  # Чтение переменной окружения FRONTEND_ORIGINS
ALLOWED_ORIGINS = (
    [o.strip() for o in origins_env.split(",") if o.strip()]  # Разделение строки по запятым и очистка от пробелов
    if origins_env else DEFAULT_ORIGINS  # Если переменная не задана, используем значения по умолчанию
)

# Примитивная Basic-аутентификация с возможностью переопределить логин/пароль через ENV.
# Чтение учетных данных администратора из переменных окружения или использование значений по умолчанию
ADMIN_USER = os.getenv("ADMIN_USER", "admin")          # Логин администратора (по умолчанию: "admin")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "123")    # Пароль администратора (по умолчанию: "123")
USERS = {ADMIN_USER: ADMIN_PASSWORD}  # Словарь пользователей для аутентификации

# Папка и лимиты для загрузки файлов
BASE_DIR = Path(__file__).parent          # Получение пути к директории текущего файла
UPLOAD_DIR = BASE_DIR / "uploads"         # Создание пути к папке для загрузок
UPLOAD_DIR.mkdir(exist_ok=True)           # Создание папки uploads (если не существует)
ALLOWED_EXT = {".jpg", ".jpeg", ".png", ".gif", ".webp"}  # Разрешенные расширения файлов

# Лимит размера загружаемого файла (по умолчанию 10 МБ), можно задать ENV MAX_UPLOAD_MB
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "10"))  # Чтение лимита из переменной окружения (по умолчанию 10 МБ)
MAX_UPLOAD_BYTES = MAX_UPLOAD_MB * 1024 * 1024  # Конвертация мегабайтов в байты

# ------------------------------------------------------------------------------
# Приложение и middleware
# ------------------------------------------------------------------------------

# Создание экземпляра FastAPI приложения с метаданными
app = FastAPI(
    title="Учебный API для постов",  # Название API
    description="API для изучения работы с REST-запросами, Basic Auth и загрузкой изображений",  # Описание
    version=__version__,  # Версия API
)

# Добавление CORS middleware для обработки кросс-доменных запросов
app.add_middleware(
    CORSMiddleware,  # Класс middleware для CORS
    allow_origins=ALLOWED_ORIGINS,  # Разрешенные origin'ы
    allow_credentials=True,  # Разрешение отправки учетных данных (cookies, авторизация)
    allow_methods=["*"],  # Разрешение всех HTTP методов (GET, POST, PUT, DELETE, etc.)
    allow_headers=["*"],  # Разрешение всех HTTP заголовков
)

# Раздача статики с загруженными файлами
# Монтирование папки uploads для обслуживания статических файлов по URL /uploads
app.mount("/uploads", StaticFiles(directory=str(UPLOAD_DIR)), name="uploads")

# ------------------------------------------------------------------------------
# Аутентификация
# ------------------------------------------------------------------------------

# Создание экземпляра HTTPBasic для базовой аутентификации
security = HTTPBasic()

# Функция для аутентификации пользователя
def authenticate_user(credentials: HTTPBasicCredentials = Depends(security)) -> str:
    username = credentials.username  # Получение имени пользователя из credentials
    password = credentials.password  # Получение пароля из credentials
    
    # Проверка существования пользователя и корректности пароля
    if username not in USERS or USERS[username] != password:
        # Вызов исключения при неудачной аутентификации
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,  # Код статуса 401 Unauthorized
            detail="Неверное имя пользователя или пароль",  # Сообщение об ошибке
            headers={"WWW-Authenticate": "Basic"},  # Заголовок для запроса аутентификации
        )
    return username  # Возврат имени пользователя при успешной аутентификации

# ------------------------------------------------------------------------------
# Модели
# ------------------------------------------------------------------------------

# Модель Pydantic для создания поста (без id и временных меток)
class PostCreate(BaseModel):
    title: str  # Заголовок поста (обязательное поле)
    content: str  # Содержание поста (обязательное поле)
    author: str  # Автор поста (обязательное поле)
    image_url: Optional[str] = None  # URL изображения (опциональное поле)

# Модель Pydantic для обновления поста (все поля опциональны)
class PostUpdate(BaseModel):
    title: Optional[str] = None  # Заголовок поста (опционально)
    content: Optional[str] = None  # Содержание поста (опционально)
    author: Optional[str] = None  # Автор поста (опционально)
    image_url: Optional[str] = None  # URL изображения (опционально)

# Модель Pydantic для полного представления поста (включая id и временные метки)
class Post(BaseModel):
    id: str  # Уникальный идентификатор поста
    title: str  # Заголовок поста
    content: str  # Содержание поста
    author: str  # Автор поста
    image_url: Optional[str] = None  # URL изображения
    created_at: datetime  # Время создания поста
    updated_at: datetime  # Время последнего обновления поста

# "БД" в памяти - словарь для хранения постов (временное хранилище)
posts_db: Dict[str, Post] = {}

# ------------------------------------------------------------------------------
# Служебные роуты
# ------------------------------------------------------------------------------

# Эндпоинт для проверки здоровья приложения
@app.get("/healthz")
def healthz():
    return {
        "status": "ok",  # Статус приложения
        "time": datetime.now(timezone.utc).isoformat(),  # Текущее время в UTC
        "version": __version__  # Версия приложения
    }

# Корневой эндпоинт
@app.get("/")
def read_root():
    # Проверка, используются ли учетные данные по умолчанию
    default_creds = (ADMIN_USER == "admin" and ADMIN_PASSWORD == "123")
    
    # Формирование информации об аутентификации
    auth_info = {"type": "Basic Auth", "login": ADMIN_USER}
    if default_creds:
        auth_info["password"] = ADMIN_PASSWORD  # Показ пароля только если используется по умолчанию
    else:
        auth_info["password"] = "*** (см. переменные окружения)"  # Сокрытие пароля если изменен через ENV

    # Возврат информации о API
    return {
        "message": "Добро пожаловать в учебный API!",
        "documentation": "/docs",  # Ссылка на автоматическую документацию
        "version": __version__,  # Версия API
        "posts_count": len(posts_db),  # Количество постов в "БД"
        "auth": auth_info,  # Информация об аутентификации
        "allowed_origins": ALLOWED_ORIGINS,  # Разрешенные origin'ы
    }

# Эндпоинт для получения информации о текущем пользователе
@app.get("/api/me")
def get_current_user(current_user: str = Depends(authenticate_user)):
    return {
        "username": current_user, 
        "message": f"Привет, {current_user}! Авторизация успешна."
    }

# ------------------------------------------------------------------------------
# Загрузка изображений
# ------------------------------------------------------------------------------

# Эндпоинт для загрузки изображений
@app.post("/api/upload")
async def upload_image(
    request: Request,  # Объект запроса для получения base_url
    file: UploadFile = File(...),  # Загружаемый файл (обязательный параметр)
    current_user: str = Depends(authenticate_user),  # Аутентификация пользователя
):
    # Проверка расширения файла
    ext = os.path.splitext(file.filename or "")[1].lower()  # Извлечение и нормализация расширения
    if ext not in ALLOWED_EXT:
        # Ошибка если расширение не разрешено
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Поддерживаются только JPG, PNG, GIF, WEBP"
        )

    # Генерация уникального имени файла
    filename = f"{uuid.uuid4().hex}{ext}"  # UUID + оригинальное расширение
    dest_path = UPLOAD_DIR / filename  # Полный путь к файлу

    # Сохраняем поток файла и контролируем лимит
    size = 0  # Счетчик размера файла
    with dest_path.open("wb") as f:  # Открытие файла для записи в бинарном режиме
        while True:
            chunk = await file.read(1024 * 1024)  # Чтение файла чанками по 1MB
            if not chunk:  # Если чанк пустой - конец файла
                break
            size += len(chunk)  # Увеличение счетчика размера
            if size > MAX_UPLOAD_BYTES:  # Проверка превышения лимита
                dest_path.unlink(missing_ok=True)  # Удаление частично загруженного файла
                # Ошибка если файл слишком большой
                raise HTTPException(
                    status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                    detail=f"Файл слишком большой (лимит {MAX_UPLOAD_MB} МБ)"
                )
            f.write(chunk)  # Запись чанка в файл

    # Формирование URL для доступа к загруженному файлу
    base = str(request.base_url).rstrip("/")  # Базовый URL API
    url = f"{base}/uploads/{filename}"  # Полный URL файла
    
    return {"url": url, "size": size}  # Возврат URL и размера файла

# ------------------------------------------------------------------------------
# CRUD для постов
# ------------------------------------------------------------------------------

# Получение списка постов с пагинацией
@app.get("/api/posts", response_model=List[Post])
def get_posts(
    _limit: Optional[int] = None,  # Лимит количества постов (опционально)
    _start: Optional[int] = None,  # Смещение для пагинации (опционально)
    current_user: str = Depends(authenticate_user),  # Аутентификация пользователя
):
    posts = list(posts_db.values())  # Получение всех постов из "БД"
    # Сортировка по времени создания (новые сверху)
    posts.sort(key=lambda x: x.created_at, reverse=True)

    # Применение пагинации
    if _start is not None and _start > 0:  # Если указано смещение
        posts = posts[_start:]  # Пропуск первых _start постов
    if _limit is not None and _limit > 0:  # Если указан лимит
        posts = posts[:_limit]  # Ограничение количества постов
    
    return posts  # Возврат списка постов

# Получение конкретного поста по ID
@app.get("/api/posts/{post_id}", response_model=Post)
def get_post(post_id: str, current_user: str = Depends(authenticate_user)):
    if post_id not in posts_db:  # Проверка существования поста
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, 
            detail="Пост не найден"
        )
    return posts_db[post_id]  # Возврат найденного поста

# Создание нового поста
@app.post("/api/posts", response_model=Post, status_code=status.HTTP_201_CREATED)
def create_post(post: PostCreate, current_user: str = Depends(authenticate_user)):
    post_id = str(uuid.uuid4())  # Генерация уникального ID
    now = datetime.now(timezone.utc)  # Текущее время в UTC
    
    # Создание объекта поста
    new_post = Post(
        id=post_id,
        title=post.title,
        content=post.content,
        author=f"{post.author} (создал: {current_user})",  # Добавление информации о создателе
        image_url=post.image_url,
        created_at=now,
        updated_at=now,
    )
    posts_db[post_id] = new_post  # Сохранение поста в "БД"
    return new_post  # Возврат созданного поста

# Обновление существующего поста
@app.put("/api/posts/{post_id}", response_model=Post)
def update_post(
    post_id: str, 
    post_update: PostUpdate, 
    current_user: str = Depends(authenticate_user)
):
    if post_id not in posts_db:  # Проверка существования поста
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, 
            detail="Пост не найден"
        )

    existing = posts_db[post_id]  # Получение существующего поста
    # Преобразование модели обновления в словарь (исключая неустановленные поля)
    update_data = post_update.dict(exclude_unset=True)

    if update_data:  # Если есть данные для обновления
        for field, value in update_data.items():
            if field == "author" and value is not None:
                # Для поля author добавляем информацию о редакторе
                setattr(existing, field, f"{value} (изменил: {current_user})")
            else:
                # Для остальных полей просто устанавливаем значения
                setattr(existing, field, value)
        # Обновление времени изменения
        existing.updated_at = datetime.now(timezone.utc)

    return existing  # Возврат обновленного поста

# Удаление поста
@app.delete("/api/posts/{post_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_post(post_id: str, current_user: str = Depends(authenticate_user)):
    if post_id not in posts_db:  # Проверка существования поста
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, 
            detail="Пост не найден"
        )
    posts_db.pop(post_id)  # Удаление поста из "БД"
    # 204 No Content — тело ответа не возвращаем

# ------------------------------------------------------------------------------
# Демо-данные
# ------------------------------------------------------------------------------

# Эндпоинт для создания демонстрационных данных
@app.post("/api/demo-data")
def create_demo_data(current_user: str = Depends(authenticate_user)):
    # Список демонстрационных постов
    demo_posts = [
        {"title": "Первый пост", "content": "Это содержимое поста", "author": "Преподаватель"},
        {"title": "Второй пост", "content": "Это содержимое поста", "author": "Студент"},
    ]
    created_posts = []  # Список созданных постов
    
    for demo in demo_posts:
        post_id = str(uuid.uuid4())  # Генерация уникального ID
        now = datetime.now(timezone.utc)  # Текущее время
        
        # Создание объекта поста
        new_post = Post(
            id=post_id,
            title=demo["title"],
            content=demo["content"],
            author=f"{demo['author']} (создал: {current_user})",  # Добавление информации о создателе
            image_url=None,
            created_at=now,
            updated_at=now,
        )
        posts_db[post_id] = new_post  # Сохранение поста
        created_posts.append(new_post)  # Добавление в список созданных
    
    return {
        "message": f"Создано {len(created_posts)} демо постов", 
        "posts": created_posts
    }

# ------------------------------------------------------------------------------
# Локальный запуск
# ------------------------------------------------------------------------------

# Блок для запуска приложения напрямую (без использования uvicorn через командную строку)
if __name__ == "__main__":
    import uvicorn
    # Запуск Uvicorn сервера
    uvicorn.run(
        app, 
        host="0.0.0.0",  # Хост для прослушивания (все интерфейсы)
        port=8000,       # Порт для прослушивания
        reload=True      # Автоматическая перезагрузка при изменении кода
    )

# ===== ПОЯСНЕНИЯ К КОММЕНТАРИЯМ =====
#
# 1. СТРУКТУРА ПРИЛОЖЕНИЯ:
#    Приложение разделено на логические секции с комментариями-разделителями
#    Каждая секция отвечает за определенную функциональность
#
# 2. КОНФИГУРАЦИЯ:
#    - CORS: настройка кросс-доменных запросов для фронтенда
#    - Аутентификация: базовая HTTP аутентификация
#    - Загрузка файлов: настройка папки, разрешенных форматов и лимитов
#
# 3. МОДЕЛИ PYDANTIC:
#    - PostCreate: для создания постов (без ID и временных меток)
#    - PostUpdate: для обновления постов (все поля опциональны)
#    - Post: полная модель поста (включая системные поля)
#
# 4. АУТЕНТИФИКАЦИЯ:
#    - HTTPBasic: стандартная базовая аутентификация
#    - authenticate_user: функция-зависимость для проверки учетных данных
#    - Защита всех API endpoints с помощью Depends(authenticate_user)
#
# 5. CRUD ОПЕРАЦИИ:
#    - Create: POST /api/posts
#    - Read: GET /api/posts и GET /api/posts/{id}
#    - Update: PUT /api/posts/{id}
#    - Delete: DELETE /api/posts/{id}
#
# 6. ЗАГРУЗКА ФАЙЛОВ:
#    - Проверка расширения файла
#    - Контроль размера файла при потоковой загрузке
#    - Генерация уникального имени файла
#    - Возврат URL для доступа к загруженному файлу
#
# 7. ОБРАБОТКА ОШИБОК:
#    - HTTPException с соответствующими кодами статусов
#    - Детальные сообщения об ошибках на русском языке
#
# 8. БЕЗОПАСНОСТЬ:
#    - Базовая аутентификация для всех операций
#    - Валидация входных данных через Pydantic
#    - Проверка типов файлов при загрузке
#    - Ограничение размера загружаемых файлов
#
# 9. ДОКУМЕНТАЦИЯ:
#    - Автоматическая генерация документации через /docs и /redoc
#    - Аннотации типов для всех параметров и возвращаемых значений
#
# 10. ЛОКАЛЬНАЯ РАЗРАБОТКА:
#     - Возможность запуска через python main.py
#     - Автоперезагрузка при изменении кода (reload=True)
#
# ===== КОНЕЦ ПОЯСНЕНИЙ =====
